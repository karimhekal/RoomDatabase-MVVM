package com.example.roomdatabase;

import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

public class MainActivity extends AppCompatActivity {
    private NoteViewModel noteViewModel;

    Context context= getApplicationContext();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        noteViewModel=ViewModelProviders.of((FragmentActivity) context).get(NoteViewModel.class); // errrrprrrr
        noteViewModel.getAllNotes().observe((LifecycleOwner) context, new Observer<List<Note>>() { // error
            @Override
            public void onChanged(List<Note> notes) {
                //this is what happens when when data changes // the code bellow should be related to changing the view so it displays the d
                Toast.makeText(context, "onChanged", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
