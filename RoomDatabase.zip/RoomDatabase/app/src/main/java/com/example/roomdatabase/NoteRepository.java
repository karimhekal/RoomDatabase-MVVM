package com.example.roomdatabase;

import android.app.Application;
import android.os.AsyncTask;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Database;

public class NoteRepository {
    private NoteDao noteDao;
    private LiveData<List<Note>> allNotes;
    public NoteRepository(Application application) // since application is subclass of context so we will pass it
    {
        NoteDatabase database= NoteDatabase.getInstance(application);
        noteDao= database.noteDao();
        allNotes = noteDao.getAllNodes();
    }
    public void insert(Note note){
        new InsertNoteAsynTask(noteDao).execute();

    }
    public void update(Note note){
        new UpdateNoteAsynTask(noteDao).execute(note);

    }
    public void delete(Note note){
        new DeleteNoteAsynTask(noteDao).execute(note);
    }
    public void deleteAllNotes(Note note){
        new DeleteAllNoteAsynTask(noteDao).execute(note);
    }

    public  LiveData<List<Note>> getAllNotes(){ //we'll have to run this in the background as a thread we will use async task to multi thread
        return allNotes;
    }

    private static class UpdateNoteAsynTask extends AsyncTask<Note,Void,Void>{

        private NoteDao noteDao; // we need this notedao to make database operations
        private UpdateNoteAsynTask (NoteDao noteDao){
            this.noteDao=noteDao;
        }
        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.update(notes[0]);
            return null;

        }
    }
    private static class DeleteNoteAsynTask extends AsyncTask<Note,Void,Void>{

        private NoteDao noteDao; // we need this notedao to make database operations
        private DeleteNoteAsynTask (NoteDao noteDao){
            this.noteDao=noteDao;
        }
        @Override
        protected Void doInBackground(Note... notes) {

            noteDao.delete(notes[0]);

            return null;

        }
    }
    private static class InsertNoteAsynTask extends AsyncTask<Note,Void,Void>{

        private NoteDao noteDao; // we need this notedao to make database operations
        private InsertNoteAsynTask (NoteDao noteDao){
            this.noteDao=noteDao;
        }
        @Override
        protected Void doInBackground(Note... notes) {

            noteDao.insert(notes[0]);

            return null;

        }
    }

    private static class DeleteAllNoteAsynTask extends AsyncTask<Note,Void,Void>{

        private NoteDao noteDao; // we need this notedao to make database operations
        private DeleteAllNoteAsynTask (NoteDao noteDao){
            this.noteDao=noteDao;
        }
        @Override
        protected Void doInBackground(Note... notes) {
            noteDao.deleteAllNodes();
            return null;

        }
    }

}
